﻿namespace Project_SAD_CUTEES
{
    partial class Add_Order
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Add_Order));
            this.label1 = new System.Windows.Forms.Label();
            this.panel_cust = new Guna.UI2.WinForms.Guna2Panel();
            this.txt_custname = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_address = new Guna.UI2.WinForms.Guna2TextBox();
            this.txt_phone = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.lbl_CD = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.panel_orderyes = new Guna.UI2.WinForms.Guna2Panel();
            this.txt_coloryes = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2PictureBox3 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox2 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.btn_viewcart = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.plus1 = new Guna.UI2.WinForms.Guna2Button();
            this.btn_addorder = new Guna.UI2.WinForms.Guna2Button();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.btn_upload = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel10 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.cmb_sablon = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.btn_polos = new Guna.UI2.WinForms.Guna2RadioButton();
            this.btn_sablon = new Guna.UI2.WinForms.Guna2RadioButton();
            this.guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.lbl_sizeyes = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.cmb_sizeyes = new Guna.UI2.WinForms.Guna2ComboBox();
            this.lbl_coloryes = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.txt_qtyyes = new Guna.UI2.WinForms.Guna2TextBox();
            this.lbl_productyes = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.cmb_productyes = new Guna.UI2.WinForms.Guna2ComboBox();
            this.lbl_OD = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.panel_orderno = new Guna.UI2.WinForms.Guna2Panel();
            this.txt_color = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2PictureBox4 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.guna2PictureBox5 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.btn_view = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button6 = new Guna.UI2.WinForms.Guna2Button();
            this.btn_addcart = new Guna.UI2.WinForms.Guna2Button();
            this.btn_no = new Guna.UI2.WinForms.Guna2RadioButton();
            this.btn_yes = new Guna.UI2.WinForms.Guna2RadioButton();
            this.guna2HtmlLabel14 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.lbl_size = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.cmb_size = new Guna.UI2.WinForms.Guna2ComboBox();
            this.lbl_color = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.txt_qty = new Guna.UI2.WinForms.Guna2TextBox();
            this.lbl_product = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.cmb_product = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2HtmlLabel18 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pict_close = new System.Windows.Forms.PictureBox();
            this.pict_minimize = new System.Windows.Forms.PictureBox();
            this.panel_cust.SuspendLayout();
            this.panel_orderyes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.panel_orderno.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pict_close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pict_minimize)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(504, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(586, 91);
            this.label1.TabIndex = 15;
            this.label1.Text = "Add New Order";
            // 
            // panel_cust
            // 
            this.panel_cust.BorderRadius = 60;
            this.panel_cust.Controls.Add(this.txt_custname);
            this.panel_cust.Controls.Add(this.txt_address);
            this.panel_cust.Controls.Add(this.txt_phone);
            this.panel_cust.Controls.Add(this.guna2HtmlLabel4);
            this.panel_cust.Controls.Add(this.guna2HtmlLabel3);
            this.panel_cust.Controls.Add(this.guna2HtmlLabel2);
            this.panel_cust.Controls.Add(this.lbl_CD);
            this.panel_cust.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(217)))), ((int)(((byte)(217)))));
            this.panel_cust.Location = new System.Drawing.Point(208, 293);
            this.panel_cust.Name = "panel_cust";
            this.panel_cust.Size = new System.Drawing.Size(629, 463);
            this.panel_cust.TabIndex = 17;
            // 
            // txt_custname
            // 
            this.txt_custname.BackColor = System.Drawing.Color.Transparent;
            this.txt_custname.BorderRadius = 15;
            this.txt_custname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_custname.DefaultText = "";
            this.txt_custname.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_custname.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_custname.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_custname.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_custname.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_custname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_custname.ForeColor = System.Drawing.Color.Black;
            this.txt_custname.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_custname.Location = new System.Drawing.Point(83, 182);
            this.txt_custname.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txt_custname.Name = "txt_custname";
            this.txt_custname.PasswordChar = '\0';
            this.txt_custname.PlaceholderText = "";
            this.txt_custname.SelectedText = "";
            this.txt_custname.Size = new System.Drawing.Size(457, 46);
            this.txt_custname.TabIndex = 2;
            // 
            // txt_address
            // 
            this.txt_address.BackColor = System.Drawing.Color.Transparent;
            this.txt_address.BorderRadius = 15;
            this.txt_address.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_address.DefaultText = "";
            this.txt_address.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_address.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_address.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_address.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_address.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_address.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_address.ForeColor = System.Drawing.Color.Black;
            this.txt_address.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_address.Location = new System.Drawing.Point(83, 380);
            this.txt_address.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txt_address.Name = "txt_address";
            this.txt_address.PasswordChar = '\0';
            this.txt_address.PlaceholderText = "";
            this.txt_address.SelectedText = "";
            this.txt_address.Size = new System.Drawing.Size(457, 46);
            this.txt_address.TabIndex = 8;
            // 
            // txt_phone
            // 
            this.txt_phone.BackColor = System.Drawing.Color.Transparent;
            this.txt_phone.BorderRadius = 15;
            this.txt_phone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_phone.DefaultText = "";
            this.txt_phone.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_phone.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_phone.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_phone.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_phone.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_phone.ForeColor = System.Drawing.Color.Black;
            this.txt_phone.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_phone.Location = new System.Drawing.Point(83, 281);
            this.txt_phone.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txt_phone.Name = "txt_phone";
            this.txt_phone.PasswordChar = '\0';
            this.txt_phone.PlaceholderText = "";
            this.txt_phone.SelectedText = "";
            this.txt_phone.Size = new System.Drawing.Size(457, 46);
            this.txt_phone.TabIndex = 7;
            this.txt_phone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_phone_KeyPress);
            // 
            // guna2HtmlLabel4
            // 
            this.guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel4.Location = new System.Drawing.Point(86, 333);
            this.guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            this.guna2HtmlLabel4.Size = new System.Drawing.Size(292, 41);
            this.guna2HtmlLabel4.TabIndex = 5;
            this.guna2HtmlLabel4.Text = "Customer Address";
            // 
            // guna2HtmlLabel3
            // 
            this.guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel3.Location = new System.Drawing.Point(83, 234);
            this.guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            this.guna2HtmlLabel3.Size = new System.Drawing.Size(396, 41);
            this.guna2HtmlLabel3.TabIndex = 3;
            this.guna2HtmlLabel3.Text = "Customer Phone Number";
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(86, 135);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(257, 41);
            this.guna2HtmlLabel2.TabIndex = 1;
            this.guna2HtmlLabel2.Text = "Customer Name";
            // 
            // lbl_CD
            // 
            this.lbl_CD.BackColor = System.Drawing.Color.Transparent;
            this.lbl_CD.Font = new System.Drawing.Font("Microsoft Sans Serif", 45F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CD.Location = new System.Drawing.Point(83, 26);
            this.lbl_CD.Name = "lbl_CD";
            this.lbl_CD.Size = new System.Drawing.Size(462, 71);
            this.lbl_CD.TabIndex = 0;
            this.lbl_CD.Text = "Customer Details";
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.FillColor = System.Drawing.Color.Gold;
            this.guna2Panel2.Location = new System.Drawing.Point(0, 162);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.Size = new System.Drawing.Size(1920, 70);
            this.guna2Panel2.TabIndex = 18;
            // 
            // panel_orderyes
            // 
            this.panel_orderyes.BorderRadius = 60;
            this.panel_orderyes.Controls.Add(this.txt_coloryes);
            this.panel_orderyes.Controls.Add(this.guna2HtmlLabel1);
            this.panel_orderyes.Controls.Add(this.guna2PictureBox3);
            this.panel_orderyes.Controls.Add(this.guna2PictureBox2);
            this.panel_orderyes.Controls.Add(this.btn_viewcart);
            this.panel_orderyes.Controls.Add(this.guna2Button2);
            this.panel_orderyes.Controls.Add(this.plus1);
            this.panel_orderyes.Controls.Add(this.btn_addorder);
            this.panel_orderyes.Controls.Add(this.guna2PictureBox1);
            this.panel_orderyes.Controls.Add(this.btn_upload);
            this.panel_orderyes.Controls.Add(this.guna2HtmlLabel10);
            this.panel_orderyes.Controls.Add(this.cmb_sablon);
            this.panel_orderyes.Controls.Add(this.guna2HtmlLabel8);
            this.panel_orderyes.Controls.Add(this.btn_polos);
            this.panel_orderyes.Controls.Add(this.btn_sablon);
            this.panel_orderyes.Controls.Add(this.guna2HtmlLabel7);
            this.panel_orderyes.Controls.Add(this.lbl_sizeyes);
            this.panel_orderyes.Controls.Add(this.cmb_sizeyes);
            this.panel_orderyes.Controls.Add(this.lbl_coloryes);
            this.panel_orderyes.Controls.Add(this.txt_qtyyes);
            this.panel_orderyes.Controls.Add(this.lbl_productyes);
            this.panel_orderyes.Controls.Add(this.cmb_productyes);
            this.panel_orderyes.Controls.Add(this.lbl_OD);
            this.panel_orderyes.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(217)))), ((int)(((byte)(217)))));
            this.panel_orderyes.Location = new System.Drawing.Point(878, 249);
            this.panel_orderyes.Name = "panel_orderyes";
            this.panel_orderyes.Size = new System.Drawing.Size(726, 628);
            this.panel_orderyes.TabIndex = 18;
            this.panel_orderyes.Visible = false;
            // 
            // txt_coloryes
            // 
            this.txt_coloryes.BackColor = System.Drawing.Color.Transparent;
            this.txt_coloryes.BorderRadius = 15;
            this.txt_coloryes.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_coloryes.DefaultText = "";
            this.txt_coloryes.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_coloryes.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_coloryes.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_coloryes.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_coloryes.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_coloryes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_coloryes.ForeColor = System.Drawing.Color.Black;
            this.txt_coloryes.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_coloryes.Location = new System.Drawing.Point(108, 233);
            this.txt_coloryes.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txt_coloryes.Name = "txt_coloryes";
            this.txt_coloryes.PasswordChar = '\0';
            this.txt_coloryes.PlaceholderText = "";
            this.txt_coloryes.SelectedText = "";
            this.txt_coloryes.Size = new System.Drawing.Size(234, 36);
            this.txt_coloryes.TabIndex = 30;
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(395, 114);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(83, 27);
            this.guna2HtmlLabel1.TabIndex = 29;
            this.guna2HtmlLabel1.Text = "Quantity";
            // 
            // guna2PictureBox3
            // 
            this.guna2PictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(51)))), ((int)(((byte)(105)))));
            this.guna2PictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox3.Image")));
            this.guna2PictureBox3.ImageRotate = 0F;
            this.guna2PictureBox3.Location = new System.Drawing.Point(436, 539);
            this.guna2PictureBox3.Name = "guna2PictureBox3";
            this.guna2PictureBox3.Size = new System.Drawing.Size(31, 34);
            this.guna2PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox3.TabIndex = 28;
            this.guna2PictureBox3.TabStop = false;
            this.guna2PictureBox3.UseTransparentBackground = true;
            // 
            // guna2PictureBox2
            // 
            this.guna2PictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox2.ImageRotate = 0F;
            this.guna2PictureBox2.Location = new System.Drawing.Point(-418, 28);
            this.guna2PictureBox2.Name = "guna2PictureBox2";
            this.guna2PictureBox2.Size = new System.Drawing.Size(64, 64);
            this.guna2PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox2.TabIndex = 27;
            this.guna2PictureBox2.TabStop = false;
            this.guna2PictureBox2.UseTransparentBackground = true;
            // 
            // btn_viewcart
            // 
            this.btn_viewcart.BackColor = System.Drawing.Color.Transparent;
            this.btn_viewcart.BorderRadius = 15;
            this.btn_viewcart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_viewcart.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_viewcart.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_viewcart.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_viewcart.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_viewcart.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(54)))), ((int)(((byte)(82)))));
            this.btn_viewcart.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.30189F);
            this.btn_viewcart.ForeColor = System.Drawing.Color.White;
            this.btn_viewcart.Location = new System.Drawing.Point(420, 530);
            this.btn_viewcart.Name = "btn_viewcart";
            this.btn_viewcart.Size = new System.Drawing.Size(183, 54);
            this.btn_viewcart.TabIndex = 26;
            this.btn_viewcart.Text = "View Cart";
            this.btn_viewcart.TextOffset = new System.Drawing.Point(18, -2);
            this.btn_viewcart.Click += new System.EventHandler(this.btn_viewcart_Click);
            // 
            // guna2Button2
            // 
            this.guna2Button2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button2.FillColor = System.Drawing.Color.Gold;
            this.guna2Button2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button2.ForeColor = System.Drawing.Color.White;
            this.guna2Button2.Location = new System.Drawing.Point(145, 548);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.Size = new System.Drawing.Size(6, 18);
            this.guna2Button2.TabIndex = 25;
            // 
            // plus1
            // 
            this.plus1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.plus1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.plus1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.plus1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.plus1.FillColor = System.Drawing.Color.Gold;
            this.plus1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.plus1.ForeColor = System.Drawing.Color.White;
            this.plus1.Location = new System.Drawing.Point(139, 554);
            this.plus1.Name = "plus1";
            this.plus1.Size = new System.Drawing.Size(18, 6);
            this.plus1.TabIndex = 24;
            // 
            // btn_addorder
            // 
            this.btn_addorder.BackColor = System.Drawing.Color.Transparent;
            this.btn_addorder.BorderRadius = 15;
            this.btn_addorder.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_addorder.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_addorder.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_addorder.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_addorder.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_addorder.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(54)))), ((int)(((byte)(82)))));
            this.btn_addorder.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.30189F);
            this.btn_addorder.ForeColor = System.Drawing.Color.White;
            this.btn_addorder.Location = new System.Drawing.Point(115, 530);
            this.btn_addorder.Name = "btn_addorder";
            this.btn_addorder.Size = new System.Drawing.Size(183, 54);
            this.btn_addorder.TabIndex = 23;
            this.btn_addorder.Text = "Add to Cart";
            this.btn_addorder.TextOffset = new System.Drawing.Point(18, -2);
            this.btn_addorder.Click += new System.EventHandler(this.btn_addorder_Click);
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.Image = global::Project_SAD_CUTEES.Properties.Resources.pngegg_removebg_preview;
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(400, 450);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(45, 32);
            this.guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox1.TabIndex = 22;
            this.guna2PictureBox1.TabStop = false;
            this.guna2PictureBox1.UseTransparentBackground = true;
            // 
            // btn_upload
            // 
            this.btn_upload.BackColor = System.Drawing.Color.Transparent;
            this.btn_upload.BorderRadius = 17;
            this.btn_upload.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_upload.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_upload.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_upload.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_upload.FillColor = System.Drawing.Color.White;
            this.btn_upload.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_upload.ForeColor = System.Drawing.Color.Black;
            this.btn_upload.Location = new System.Drawing.Point(385, 439);
            this.btn_upload.Name = "btn_upload";
            this.btn_upload.Size = new System.Drawing.Size(241, 54);
            this.btn_upload.TabIndex = 21;
            this.btn_upload.Text = "Upload Image";
            this.btn_upload.TextOffset = new System.Drawing.Point(20, 0);
            this.btn_upload.Click += new System.EventHandler(this.btn_upload_Click);
            // 
            // guna2HtmlLabel10
            // 
            this.guna2HtmlLabel10.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel10.Location = new System.Drawing.Point(100, 450);
            this.guna2HtmlLabel10.Name = "guna2HtmlLabel10";
            this.guna2HtmlLabel10.Size = new System.Drawing.Size(125, 31);
            this.guna2HtmlLabel10.TabIndex = 20;
            this.guna2HtmlLabel10.Text = "Print Image";
            // 
            // cmb_sablon
            // 
            this.cmb_sablon.AutoRoundedCorners = true;
            this.cmb_sablon.BackColor = System.Drawing.Color.Transparent;
            this.cmb_sablon.BorderRadius = 17;
            this.cmb_sablon.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmb_sablon.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_sablon.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmb_sablon.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmb_sablon.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.cmb_sablon.ForeColor = System.Drawing.Color.Black;
            this.cmb_sablon.ItemHeight = 30;
            this.cmb_sablon.Location = new System.Drawing.Point(385, 375);
            this.cmb_sablon.Name = "cmb_sablon";
            this.cmb_sablon.Size = new System.Drawing.Size(241, 36);
            this.cmb_sablon.TabIndex = 18;
            this.cmb_sablon.SelectionChangeCommitted += new System.EventHandler(this.cmb_sablon_SelectionChangeCommitted);
            // 
            // guna2HtmlLabel8
            // 
            this.guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel8.Location = new System.Drawing.Point(99, 375);
            this.guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            this.guna2HtmlLabel8.Size = new System.Drawing.Size(105, 31);
            this.guna2HtmlLabel8.TabIndex = 17;
            this.guna2HtmlLabel8.Text = "Print Size";
            // 
            // btn_polos
            // 
            this.btn_polos.AutoSize = true;
            this.btn_polos.BackColor = System.Drawing.Color.Transparent;
            this.btn_polos.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(54)))), ((int)(((byte)(82)))));
            this.btn_polos.CheckedState.BorderThickness = 0;
            this.btn_polos.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(54)))), ((int)(((byte)(82)))));
            this.btn_polos.CheckedState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(54)))), ((int)(((byte)(82)))));
            this.btn_polos.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.btn_polos.Location = new System.Drawing.Point(416, 302);
            this.btn_polos.Name = "btn_polos";
            this.btn_polos.Size = new System.Drawing.Size(93, 33);
            this.btn_polos.TabIndex = 16;
            this.btn_polos.Text = "Polos";
            this.btn_polos.UncheckedState.BorderColor = System.Drawing.Color.White;
            this.btn_polos.UncheckedState.BorderThickness = 2;
            this.btn_polos.UncheckedState.FillColor = System.Drawing.Color.White;
            this.btn_polos.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.btn_polos.UseVisualStyleBackColor = false;
            this.btn_polos.CheckedChanged += new System.EventHandler(this.btn_polos_CheckedChanged);
            // 
            // btn_sablon
            // 
            this.btn_sablon.AutoSize = true;
            this.btn_sablon.BackColor = System.Drawing.Color.Transparent;
            this.btn_sablon.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(54)))), ((int)(((byte)(82)))));
            this.btn_sablon.CheckedState.BorderThickness = 2;
            this.btn_sablon.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(54)))), ((int)(((byte)(82)))));
            this.btn_sablon.CheckedState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(54)))), ((int)(((byte)(82)))));
            this.btn_sablon.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.btn_sablon.Location = new System.Drawing.Point(241, 302);
            this.btn_sablon.Name = "btn_sablon";
            this.btn_sablon.Size = new System.Drawing.Size(107, 33);
            this.btn_sablon.TabIndex = 15;
            this.btn_sablon.Text = "Sablon";
            this.btn_sablon.UncheckedState.BorderColor = System.Drawing.Color.White;
            this.btn_sablon.UncheckedState.BorderThickness = 2;
            this.btn_sablon.UncheckedState.FillColor = System.Drawing.Color.White;
            this.btn_sablon.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.btn_sablon.UseVisualStyleBackColor = false;
            // 
            // guna2HtmlLabel7
            // 
            this.guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel7.Location = new System.Drawing.Point(100, 302);
            this.guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            this.guna2HtmlLabel7.Size = new System.Drawing.Size(58, 31);
            this.guna2HtmlLabel7.TabIndex = 14;
            this.guna2HtmlLabel7.Text = "Type";
            // 
            // lbl_sizeyes
            // 
            this.lbl_sizeyes.BackColor = System.Drawing.Color.Transparent;
            this.lbl_sizeyes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sizeyes.Location = new System.Drawing.Point(395, 200);
            this.lbl_sizeyes.Name = "lbl_sizeyes";
            this.lbl_sizeyes.Size = new System.Drawing.Size(45, 27);
            this.lbl_sizeyes.TabIndex = 13;
            this.lbl_sizeyes.Text = "Size";
            // 
            // cmb_sizeyes
            // 
            this.cmb_sizeyes.AutoRoundedCorners = true;
            this.cmb_sizeyes.BackColor = System.Drawing.Color.Transparent;
            this.cmb_sizeyes.BorderRadius = 17;
            this.cmb_sizeyes.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmb_sizeyes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_sizeyes.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmb_sizeyes.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmb_sizeyes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.cmb_sizeyes.ForeColor = System.Drawing.Color.Black;
            this.cmb_sizeyes.ItemHeight = 30;
            this.cmb_sizeyes.Items.AddRange(new object[] {
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "XXL"});
            this.cmb_sizeyes.Location = new System.Drawing.Point(385, 233);
            this.cmb_sizeyes.Name = "cmb_sizeyes";
            this.cmb_sizeyes.Size = new System.Drawing.Size(241, 36);
            this.cmb_sizeyes.TabIndex = 12;
            // 
            // lbl_coloryes
            // 
            this.lbl_coloryes.BackColor = System.Drawing.Color.Transparent;
            this.lbl_coloryes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_coloryes.Location = new System.Drawing.Point(108, 200);
            this.lbl_coloryes.Name = "lbl_coloryes";
            this.lbl_coloryes.Size = new System.Drawing.Size(54, 27);
            this.lbl_coloryes.TabIndex = 11;
            this.lbl_coloryes.Text = "Color";
            // 
            // txt_qtyyes
            // 
            this.txt_qtyyes.BackColor = System.Drawing.Color.Transparent;
            this.txt_qtyyes.BorderRadius = 15;
            this.txt_qtyyes.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_qtyyes.DefaultText = "";
            this.txt_qtyyes.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_qtyyes.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_qtyyes.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_qtyyes.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_qtyyes.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_qtyyes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_qtyyes.ForeColor = System.Drawing.Color.Black;
            this.txt_qtyyes.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_qtyyes.Location = new System.Drawing.Point(385, 147);
            this.txt_qtyyes.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txt_qtyyes.Name = "txt_qtyyes";
            this.txt_qtyyes.PasswordChar = '\0';
            this.txt_qtyyes.PlaceholderText = "";
            this.txt_qtyyes.SelectedText = "";
            this.txt_qtyyes.Size = new System.Drawing.Size(218, 36);
            this.txt_qtyyes.TabIndex = 0;
            this.txt_qtyyes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_qtyyes_KeyPress);
            // 
            // lbl_productyes
            // 
            this.lbl_productyes.BackColor = System.Drawing.Color.Transparent;
            this.lbl_productyes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_productyes.Location = new System.Drawing.Point(108, 114);
            this.lbl_productyes.Name = "lbl_productyes";
            this.lbl_productyes.Size = new System.Drawing.Size(139, 27);
            this.lbl_productyes.TabIndex = 9;
            this.lbl_productyes.Text = "Product Name";
            // 
            // cmb_productyes
            // 
            this.cmb_productyes.AutoRoundedCorners = true;
            this.cmb_productyes.BackColor = System.Drawing.Color.Transparent;
            this.cmb_productyes.BorderRadius = 17;
            this.cmb_productyes.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmb_productyes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_productyes.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmb_productyes.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmb_productyes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.cmb_productyes.ForeColor = System.Drawing.Color.Black;
            this.cmb_productyes.ItemHeight = 30;
            this.cmb_productyes.Items.AddRange(new object[] {
            "hahaha",
            "hihi",
            "ho"});
            this.cmb_productyes.Location = new System.Drawing.Point(108, 147);
            this.cmb_productyes.Name = "cmb_productyes";
            this.cmb_productyes.Size = new System.Drawing.Size(241, 36);
            this.cmb_productyes.TabIndex = 8;
            this.cmb_productyes.SelectionChangeCommitted += new System.EventHandler(this.cmb_productyes_SelectionChangeCommitted);
            // 
            // lbl_OD
            // 
            this.lbl_OD.BackColor = System.Drawing.Color.Transparent;
            this.lbl_OD.Font = new System.Drawing.Font("Microsoft Sans Serif", 45F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_OD.Location = new System.Drawing.Point(186, 28);
            this.lbl_OD.Name = "lbl_OD";
            this.lbl_OD.Size = new System.Drawing.Size(356, 71);
            this.lbl_OD.TabIndex = 7;
            this.lbl_OD.Text = "Order Details";
            this.lbl_OD.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel_orderno
            // 
            this.panel_orderno.BorderRadius = 60;
            this.panel_orderno.Controls.Add(this.txt_color);
            this.panel_orderno.Controls.Add(this.guna2HtmlLabel5);
            this.panel_orderno.Controls.Add(this.guna2PictureBox4);
            this.panel_orderno.Controls.Add(this.guna2PictureBox5);
            this.panel_orderno.Controls.Add(this.btn_view);
            this.panel_orderno.Controls.Add(this.guna2Button5);
            this.panel_orderno.Controls.Add(this.guna2Button6);
            this.panel_orderno.Controls.Add(this.btn_addcart);
            this.panel_orderno.Controls.Add(this.btn_no);
            this.panel_orderno.Controls.Add(this.btn_yes);
            this.panel_orderno.Controls.Add(this.guna2HtmlLabel14);
            this.panel_orderno.Controls.Add(this.lbl_size);
            this.panel_orderno.Controls.Add(this.cmb_size);
            this.panel_orderno.Controls.Add(this.lbl_color);
            this.panel_orderno.Controls.Add(this.txt_qty);
            this.panel_orderno.Controls.Add(this.lbl_product);
            this.panel_orderno.Controls.Add(this.cmb_product);
            this.panel_orderno.Controls.Add(this.guna2HtmlLabel18);
            this.panel_orderno.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(217)))), ((int)(((byte)(217)))));
            this.panel_orderno.Location = new System.Drawing.Point(1692, 249);
            this.panel_orderno.Name = "panel_orderno";
            this.panel_orderno.Size = new System.Drawing.Size(726, 455);
            this.panel_orderno.TabIndex = 29;
            // 
            // txt_color
            // 
            this.txt_color.BackColor = System.Drawing.Color.Transparent;
            this.txt_color.BorderRadius = 15;
            this.txt_color.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_color.DefaultText = "";
            this.txt_color.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_color.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_color.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_color.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_color.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_color.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_color.ForeColor = System.Drawing.Color.Black;
            this.txt_color.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_color.Location = new System.Drawing.Point(108, 233);
            this.txt_color.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txt_color.Name = "txt_color";
            this.txt_color.PasswordChar = '\0';
            this.txt_color.PlaceholderText = "";
            this.txt_color.SelectedText = "";
            this.txt_color.Size = new System.Drawing.Size(234, 36);
            this.txt_color.TabIndex = 31;
            // 
            // guna2HtmlLabel5
            // 
            this.guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel5.Location = new System.Drawing.Point(395, 114);
            this.guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            this.guna2HtmlLabel5.Size = new System.Drawing.Size(83, 27);
            this.guna2HtmlLabel5.TabIndex = 29;
            this.guna2HtmlLabel5.Text = "Quantity";
            // 
            // guna2PictureBox4
            // 
            this.guna2PictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("guna2PictureBox4.Image")));
            this.guna2PictureBox4.ImageRotate = 0F;
            this.guna2PictureBox4.Location = new System.Drawing.Point(416, 375);
            this.guna2PictureBox4.Name = "guna2PictureBox4";
            this.guna2PictureBox4.Size = new System.Drawing.Size(31, 34);
            this.guna2PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.guna2PictureBox4.TabIndex = 28;
            this.guna2PictureBox4.TabStop = false;
            this.guna2PictureBox4.UseTransparentBackground = true;
            // 
            // guna2PictureBox5
            // 
            this.guna2PictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox5.ImageRotate = 0F;
            this.guna2PictureBox5.Location = new System.Drawing.Point(-418, 28);
            this.guna2PictureBox5.Name = "guna2PictureBox5";
            this.guna2PictureBox5.Size = new System.Drawing.Size(64, 64);
            this.guna2PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2PictureBox5.TabIndex = 27;
            this.guna2PictureBox5.TabStop = false;
            this.guna2PictureBox5.UseTransparentBackground = true;
            // 
            // btn_view
            // 
            this.btn_view.BackColor = System.Drawing.Color.Transparent;
            this.btn_view.BorderRadius = 15;
            this.btn_view.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_view.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_view.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_view.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_view.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_view.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(54)))), ((int)(((byte)(82)))));
            this.btn_view.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.30189F);
            this.btn_view.ForeColor = System.Drawing.Color.White;
            this.btn_view.Location = new System.Drawing.Point(400, 363);
            this.btn_view.Name = "btn_view";
            this.btn_view.Size = new System.Drawing.Size(183, 54);
            this.btn_view.TabIndex = 26;
            this.btn_view.Text = "View Cart";
            this.btn_view.TextOffset = new System.Drawing.Point(18, 0);
            this.btn_view.Click += new System.EventHandler(this.btn_view_Click);
            // 
            // guna2Button5
            // 
            this.guna2Button5.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button5.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button5.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button5.FillColor = System.Drawing.Color.Gold;
            this.guna2Button5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button5.ForeColor = System.Drawing.Color.White;
            this.guna2Button5.Location = new System.Drawing.Point(145, 382);
            this.guna2Button5.Name = "guna2Button5";
            this.guna2Button5.Size = new System.Drawing.Size(6, 18);
            this.guna2Button5.TabIndex = 25;
            // 
            // guna2Button6
            // 
            this.guna2Button6.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button6.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button6.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button6.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button6.FillColor = System.Drawing.Color.Gold;
            this.guna2Button6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button6.ForeColor = System.Drawing.Color.White;
            this.guna2Button6.Location = new System.Drawing.Point(139, 388);
            this.guna2Button6.Name = "guna2Button6";
            this.guna2Button6.Size = new System.Drawing.Size(18, 6);
            this.guna2Button6.TabIndex = 24;
            // 
            // btn_addcart
            // 
            this.btn_addcart.BackColor = System.Drawing.Color.Transparent;
            this.btn_addcart.BorderRadius = 15;
            this.btn_addcart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_addcart.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btn_addcart.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btn_addcart.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btn_addcart.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btn_addcart.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(54)))), ((int)(((byte)(82)))));
            this.btn_addcart.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.30189F);
            this.btn_addcart.ForeColor = System.Drawing.Color.White;
            this.btn_addcart.Location = new System.Drawing.Point(115, 363);
            this.btn_addcart.Name = "btn_addcart";
            this.btn_addcart.Size = new System.Drawing.Size(183, 54);
            this.btn_addcart.TabIndex = 23;
            this.btn_addcart.Text = "Add to Cart";
            this.btn_addcart.TextOffset = new System.Drawing.Point(18, 0);
            this.btn_addcart.Click += new System.EventHandler(this.btn_addcart_Click);
            // 
            // btn_no
            // 
            this.btn_no.AutoSize = true;
            this.btn_no.BackColor = System.Drawing.Color.Transparent;
            this.btn_no.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(54)))), ((int)(((byte)(82)))));
            this.btn_no.CheckedState.BorderThickness = 0;
            this.btn_no.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(54)))), ((int)(((byte)(82)))));
            this.btn_no.CheckedState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(54)))), ((int)(((byte)(82)))));
            this.btn_no.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.btn_no.Location = new System.Drawing.Point(416, 302);
            this.btn_no.Name = "btn_no";
            this.btn_no.Size = new System.Drawing.Size(93, 33);
            this.btn_no.TabIndex = 16;
            this.btn_no.Text = "Polos";
            this.btn_no.UncheckedState.BorderColor = System.Drawing.Color.White;
            this.btn_no.UncheckedState.BorderThickness = 2;
            this.btn_no.UncheckedState.FillColor = System.Drawing.Color.White;
            this.btn_no.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.btn_no.UseVisualStyleBackColor = false;
            this.btn_no.CheckedChanged += new System.EventHandler(this.btn_no_CheckedChanged);
            // 
            // btn_yes
            // 
            this.btn_yes.AutoSize = true;
            this.btn_yes.BackColor = System.Drawing.Color.Transparent;
            this.btn_yes.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(54)))), ((int)(((byte)(82)))));
            this.btn_yes.CheckedState.BorderThickness = 2;
            this.btn_yes.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(54)))), ((int)(((byte)(82)))));
            this.btn_yes.CheckedState.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(54)))), ((int)(((byte)(82)))));
            this.btn_yes.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.btn_yes.Location = new System.Drawing.Point(241, 302);
            this.btn_yes.Name = "btn_yes";
            this.btn_yes.Size = new System.Drawing.Size(107, 33);
            this.btn_yes.TabIndex = 15;
            this.btn_yes.Text = "Sablon";
            this.btn_yes.UncheckedState.BorderColor = System.Drawing.Color.White;
            this.btn_yes.UncheckedState.BorderThickness = 2;
            this.btn_yes.UncheckedState.FillColor = System.Drawing.Color.White;
            this.btn_yes.UncheckedState.InnerColor = System.Drawing.Color.White;
            this.btn_yes.UseVisualStyleBackColor = false;
            this.btn_yes.CheckedChanged += new System.EventHandler(this.btn_yes_CheckedChanged);
            // 
            // guna2HtmlLabel14
            // 
            this.guna2HtmlLabel14.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel14.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel14.Location = new System.Drawing.Point(100, 302);
            this.guna2HtmlLabel14.Name = "guna2HtmlLabel14";
            this.guna2HtmlLabel14.Size = new System.Drawing.Size(58, 31);
            this.guna2HtmlLabel14.TabIndex = 14;
            this.guna2HtmlLabel14.Text = "Type";
            // 
            // lbl_size
            // 
            this.lbl_size.BackColor = System.Drawing.Color.Transparent;
            this.lbl_size.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_size.Location = new System.Drawing.Point(395, 200);
            this.lbl_size.Name = "lbl_size";
            this.lbl_size.Size = new System.Drawing.Size(45, 27);
            this.lbl_size.TabIndex = 13;
            this.lbl_size.Text = "Size";
            // 
            // cmb_size
            // 
            this.cmb_size.AutoRoundedCorners = true;
            this.cmb_size.BackColor = System.Drawing.Color.Transparent;
            this.cmb_size.BorderRadius = 17;
            this.cmb_size.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmb_size.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_size.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmb_size.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmb_size.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.cmb_size.ForeColor = System.Drawing.Color.Black;
            this.cmb_size.ItemHeight = 30;
            this.cmb_size.Items.AddRange(new object[] {
            "XS",
            "S",
            "M",
            "L",
            "XL",
            "XXL"});
            this.cmb_size.Location = new System.Drawing.Point(385, 233);
            this.cmb_size.Name = "cmb_size";
            this.cmb_size.Size = new System.Drawing.Size(241, 36);
            this.cmb_size.TabIndex = 12;
            this.cmb_size.SelectedIndexChanged += new System.EventHandler(this.cmb_size_SelectedIndexChanged);
            // 
            // lbl_color
            // 
            this.lbl_color.BackColor = System.Drawing.Color.Transparent;
            this.lbl_color.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_color.Location = new System.Drawing.Point(108, 200);
            this.lbl_color.Name = "lbl_color";
            this.lbl_color.Size = new System.Drawing.Size(54, 27);
            this.lbl_color.TabIndex = 11;
            this.lbl_color.Text = "Color";
            // 
            // txt_qty
            // 
            this.txt_qty.BackColor = System.Drawing.Color.Transparent;
            this.txt_qty.BorderRadius = 15;
            this.txt_qty.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txt_qty.DefaultText = "";
            this.txt_qty.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txt_qty.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txt_qty.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_qty.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txt_qty.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_qty.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_qty.ForeColor = System.Drawing.Color.Black;
            this.txt_qty.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txt_qty.Location = new System.Drawing.Point(385, 147);
            this.txt_qty.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txt_qty.Name = "txt_qty";
            this.txt_qty.PasswordChar = '\0';
            this.txt_qty.PlaceholderText = "";
            this.txt_qty.SelectedText = "";
            this.txt_qty.Size = new System.Drawing.Size(218, 36);
            this.txt_qty.TabIndex = 0;
            this.txt_qty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_qty_KeyPress);
            // 
            // lbl_product
            // 
            this.lbl_product.BackColor = System.Drawing.Color.Transparent;
            this.lbl_product.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_product.Location = new System.Drawing.Point(108, 114);
            this.lbl_product.Name = "lbl_product";
            this.lbl_product.Size = new System.Drawing.Size(139, 27);
            this.lbl_product.TabIndex = 9;
            this.lbl_product.Text = "Product Name";
            // 
            // cmb_product
            // 
            this.cmb_product.AutoRoundedCorners = true;
            this.cmb_product.BackColor = System.Drawing.Color.Transparent;
            this.cmb_product.BorderRadius = 17;
            this.cmb_product.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cmb_product.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_product.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmb_product.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cmb_product.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F);
            this.cmb_product.ForeColor = System.Drawing.Color.Black;
            this.cmb_product.ItemHeight = 30;
            this.cmb_product.Items.AddRange(new object[] {
            "hahah",
            "hihi",
            "ho"});
            this.cmb_product.Location = new System.Drawing.Point(108, 147);
            this.cmb_product.Name = "cmb_product";
            this.cmb_product.Size = new System.Drawing.Size(241, 36);
            this.cmb_product.TabIndex = 8;
            this.cmb_product.SelectionChangeCommitted += new System.EventHandler(this.cmb_product_SelectionChangeCommitted);
            // 
            // guna2HtmlLabel18
            // 
            this.guna2HtmlLabel18.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel18.Font = new System.Drawing.Font("Microsoft Sans Serif", 45F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel18.Location = new System.Drawing.Point(186, 28);
            this.guna2HtmlLabel18.Name = "guna2HtmlLabel18";
            this.guna2HtmlLabel18.Size = new System.Drawing.Size(356, 71);
            this.guna2HtmlLabel18.TabIndex = 7;
            this.guna2HtmlLabel18.Text = "Order Details";
            this.guna2HtmlLabel18.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Project_SAD_CUTEES.Properties.Resources.back;
            this.pictureBox1.Location = new System.Drawing.Point(98, 30);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(156, 77);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pict_close
            // 
            this.pict_close.BackColor = System.Drawing.Color.Transparent;
            this.pict_close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pict_close.Image = global::Project_SAD_CUTEES.Properties.Resources.White_close_icon;
            this.pict_close.Location = new System.Drawing.Point(1854, 7);
            this.pict_close.Name = "pict_close";
            this.pict_close.Size = new System.Drawing.Size(44, 44);
            this.pict_close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pict_close.TabIndex = 14;
            this.pict_close.TabStop = false;
            this.pict_close.Click += new System.EventHandler(this.pict_close_Click);
            // 
            // pict_minimize
            // 
            this.pict_minimize.BackColor = System.Drawing.Color.Transparent;
            this.pict_minimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pict_minimize.Image = global::Project_SAD_CUTEES.Properties.Resources.White_minimize_icon;
            this.pict_minimize.Location = new System.Drawing.Point(1792, 7);
            this.pict_minimize.Name = "pict_minimize";
            this.pict_minimize.Size = new System.Drawing.Size(44, 44);
            this.pict_minimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pict_minimize.TabIndex = 13;
            this.pict_minimize.TabStop = false;
            this.pict_minimize.Click += new System.EventHandler(this.pict_minimize_Click);
            // 
            // Add_Order
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(50)))), ((int)(((byte)(90)))));
            this.ClientSize = new System.Drawing.Size(1920, 1080);
            this.Controls.Add(this.panel_orderno);
            this.Controls.Add(this.guna2Panel2);
            this.Controls.Add(this.panel_cust);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pict_close);
            this.Controls.Add(this.pict_minimize);
            this.Controls.Add(this.panel_orderyes);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Add_Order";
            this.Text = "Add_Order";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Add_Order_Load);
            this.panel_cust.ResumeLayout(false);
            this.panel_cust.PerformLayout();
            this.panel_orderyes.ResumeLayout(false);
            this.panel_orderyes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.panel_orderno.ResumeLayout(false);
            this.panel_orderno.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pict_close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pict_minimize)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pict_close;
        private System.Windows.Forms.PictureBox pict_minimize;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2Panel panel_cust;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2Panel panel_orderyes;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbl_CD;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2TextBox txt_custname;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbl_OD;
        private Guna.UI2.WinForms.Guna2ComboBox cmb_productyes;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbl_productyes;
        private Guna.UI2.WinForms.Guna2TextBox txt_qtyyes;
        private Guna.UI2.WinForms.Guna2TextBox txt_address;
        private Guna.UI2.WinForms.Guna2TextBox txt_phone;
        private Guna.UI2.WinForms.Guna2ComboBox cmb_sizeyes;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbl_coloryes;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel10;
        private Guna.UI2.WinForms.Guna2ComboBox cmb_sablon;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private Guna.UI2.WinForms.Guna2RadioButton btn_polos;
        private Guna.UI2.WinForms.Guna2RadioButton btn_sablon;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbl_sizeyes;
        private Guna.UI2.WinForms.Guna2Button btn_upload;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2Button plus1;
        private Guna.UI2.WinForms.Guna2Button btn_addorder;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox2;
        private Guna.UI2.WinForms.Guna2Button btn_viewcart;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox3;
        private Guna.UI2.WinForms.Guna2Panel panel_orderno;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox4;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox5;
        private Guna.UI2.WinForms.Guna2Button btn_view;
        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private Guna.UI2.WinForms.Guna2Button guna2Button6;
        private Guna.UI2.WinForms.Guna2Button btn_addcart;
        private Guna.UI2.WinForms.Guna2RadioButton btn_no;
        private Guna.UI2.WinForms.Guna2RadioButton btn_yes;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel14;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbl_size;
        private Guna.UI2.WinForms.Guna2ComboBox cmb_size;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbl_color;
        private Guna.UI2.WinForms.Guna2TextBox txt_qty;
        private Guna.UI2.WinForms.Guna2HtmlLabel lbl_product;
        private Guna.UI2.WinForms.Guna2ComboBox cmb_product;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel18;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2TextBox txt_coloryes;
        private Guna.UI2.WinForms.Guna2TextBox txt_color;
    }
}