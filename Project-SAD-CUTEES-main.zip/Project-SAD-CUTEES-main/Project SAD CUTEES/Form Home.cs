﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Guna.UI2.WinForms;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Project_SAD_CUTEES
{
    public partial class Form_Home : Form
    {
        Guna2Panel[] pesanan;
        Guna2Panel[] order;
        Guna2HtmlLabel[] lbl_cust;
        Guna2HtmlLabel[] lbl_order;
        Guna2HtmlLabel[] status;
        Guna2HtmlLabel[] lbl_product;
        Guna2HtmlLabel[] lbl_type;
        Guna2HtmlLabel[] lbl_qty; 
        Guna2HtmlLabel[] lbl_deadline;
        Guna2HtmlLabel[] lbl_total;
        Guna2PictureBox[] pb;

        private Form1 form1;
        public int y;
        public int y1;
        public int y2;
        public int y3;
        public int y4;
        public int y5;
        
        public static string firstname;
        public Form_Home()
        {
            InitializeComponent();
            Form1.workingDirectory = Environment.CurrentDirectory;
            Form1.projectDirectory = Directory.GetParent(Form1.workingDirectory).Parent.FullName;
            form1 = new Form1(); 
            pict_logo.Location = new Point((panel1.Width - pict_logo.Width)/2, (panel1.Height - pict_logo.Height)/2);

            lbl_orders.Location = new Point(((panel1.Width - lbl_orders.Width)/ 2) - 600, panel1.Top + 5);
            lbl_expense.Location = new Point(((panel1.Width - lbl_expense.Width) / 2) - 250, panel1.Top + 5);
            lbl_transaction.Location = new Point(((panel1.Width - lbl_transaction.Width) / 2) + 150, panel1.Top + 5);
            lbl_inventory.Location = new Point(((panel1.Width - lbl_inventory.Width) / 2) + 550, panel1.Top + 5);

            btn_current.Location = new Point(((panel1.Width - btn_current.Width) / 2) - 597, panel1.Top + 43);
            txt_search.GotFocus += RemoveText;
            txt_search.LostFocus += AddText;
        }

        private void AddText(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_search.Text))
            {
                txt_search.Text = "Search Order by ID / Name";
                txt_search.ForeColor = Color.DarkGray;
            }
        }

        private void RemoveText(object sender, EventArgs e)
        {
            if (txt_search.Text == "Search Order by ID / Name")
            {
                txt_search.Text = "";
                txt_search.ForeColor = Color.Black;
            }
        }

        private void Form_Home_Load(object sender, EventArgs e)
        {
            DataTable Login = new DataTable();
            Form1.sqlquery = $"SELECT first_name FROM accounts WHERE(email = '{Form1.email}' and passwords = '{Form1.pass}')";
            Form1.sqlcommand = new MySqlCommand(Form1.sqlquery, Form1.sqlconnect);
            Form1.mySqlDataAdapter = new MySqlDataAdapter(Form1.sqlcommand);
            Form1.mySqlDataAdapter.Fill(Login);
            lbl_signup.Text = Login.Rows[0][0].ToString();
            firstname = Login.Rows[0][0].ToString();
            //DataTable s = new DataTable();
            //Form1.sqlquery = $"SELECT gambar_sablon FROM produk limit 1";
            //Form1.sqlcommand = new MySqlCommand(Form1.sqlquery, Form1.sqlconnect);
            //Form1.mySqlDataAdapter = new MySqlDataAdapter(Form1.sqlcommand);
            //Form1.mySqlDataAdapter.Fill(s);

            DataTable dtorder = new DataTable();
            Form1.sqlquery = $"SELECT order_id from `order`;";
            Form1.sqlcommand = new MySqlCommand(Form1.sqlquery, Form1.sqlconnect);
            Form1.mySqlDataAdapter = new MySqlDataAdapter(Form1.sqlcommand);
            Form1.mySqlDataAdapter.Fill(dtorder);
            DataTable dtjum = new DataTable();
            Form1.sqlquery = "select order_id,count(order_id) from detail_order group by 1;";
            Form1.sqlcommand = new MySqlCommand(Form1.sqlquery, Form1.sqlconnect);
            Form1.mySqlDataAdapter = new MySqlDataAdapter(Form1.sqlcommand);
            Form1.mySqlDataAdapter.Fill(dtjum);
            //MessageBox.Show(dtorder.Rows.Count.ToString());
            pesanan = new Guna2Panel[dtorder.Rows.Count];
            order = new Guna2Panel[dtorder.Rows.Count];
            guna2Panel1.AutoScroll = true;
            DataTable dtcust = new DataTable();
            y = 78;
            y1 = 139;
            y2 = 17;
            for (int i = 0; i < dtorder.Rows.Count; i++)
            {
                int height = Convert.ToInt32(dtjum.Rows[i][1]);
                Form1.sqlquery = $"SELECT c.nama_customer, o.order_id, o.status_order from `order` o, customer c where c.customer_id = o.customer_id and o.order_id = '{dtorder.Rows[i][0]}' ;";
                Form1.sqlcommand = new MySqlCommand(Form1.sqlquery, Form1.sqlconnect);
                Form1.mySqlDataAdapter = new MySqlDataAdapter(Form1.sqlcommand);
                Form1.mySqlDataAdapter.Fill(dtcust);

                pesanan[i] = new Guna2Panel();
                pesanan[i].Location = new Point(0, y);
                pesanan[i].Size = new Size(1700, 61);
                pesanan[i].FillColor = Color.White;
                order[i] = new Guna2Panel();
                order[i].Location = new Point(0, 139);
                order[i].Size = new Size(1700, height * 300);
               // order[i].FillColor = Color.LightGray;
                
                y += order[i].Height;
                y1 += pesanan[i].Height;
                guna2Panel1.Controls.Add(pesanan[i]);
                guna2Panel1.Controls.Add(order[i]);
            }
            lbl_cust = new Guna2HtmlLabel[dtcust.Rows.Count];
            lbl_order = new Guna2HtmlLabel[dtcust.Rows.Count];
            status = new Guna2HtmlLabel[dtcust.Rows.Count];
            for (int i = 0; i < dtcust.Rows.Count; i++)
            {
                lbl_cust[i] = new Guna2HtmlLabel();
                lbl_cust[i].Location = new Point(60, 12);
                lbl_cust[i].Size = new Size(255, 39);
                lbl_cust[i].Font = new Font("Microsoft Sans Serif", 24);
                lbl_cust[i].Text = dtcust.Rows[i][0].ToString();
                lbl_order[i] = new Guna2HtmlLabel();
                lbl_order[i].Location = new Point(943, 12);
                lbl_order[i].Size = new Size(255, 39);
                lbl_order[i].Font = new Font("Microsoft Sans Serif", 24);
                lbl_order[i].Text ="Order ID : " + dtcust.Rows[i][1].ToString();
                status[i] = new Guna2HtmlLabel();
                status[i].Location = new Point(1357, 10);
                status[i].Size = new Size(255, 39);
                status[i].Font = new Font("Microsoft Sans Serif", 24);
                status[i].BorderStyle = BorderStyle.FixedSingle;
                
                status[i].ForeColor = Color.Black;
                status[i].Text = dtcust.Rows[i][2].ToString();
                if (dtcust.Rows[i][2].ToString() == "Need to process")
                {
                    status[i].BackColor = Color.OrangeRed;
                    status[i].Text = dtcust.Rows[i][2].ToString();

                }
                else if (dtcust.Rows[i][2].ToString() == "In process")
                {
                    status[i].BackColor = Color.Gold;
                    status[i].Text = dtcust.Rows[i][2].ToString();
                    status[i].ForeColor = Color.Black;
                }
                pesanan[i].Controls.Add(lbl_cust[i]);
                pesanan[i].Controls.Add(lbl_order[i]);
                pesanan[i].Controls.Add(status[i]);

            }
           
            for(int i = 0; i < dtorder.Rows.Count; i++)
            {
                DataTable dtdetail = new DataTable();
                Form1.sqlquery = $"select p.nama_produk, u.nama_sablon, p.warna,p.ukuran,p.stock, date_format(o.deadline,\"%d %M %Y\"), o.total_harga, p.gambar_sablon\r\nfrom produk p, ukuran_sablon u, `order` o, detail_order d\r\nwhere p.sablon_id = u.sablon_id and d.order_id = o.order_id and d.produk_id = p.PRODUK_ID and o.ORDER_ID = '{dtorder.Rows[i][0].ToString()}' ;";
                Form1.sqlcommand = new MySqlCommand(Form1.sqlquery, Form1.sqlconnect);
                Form1.mySqlDataAdapter = new MySqlDataAdapter(Form1.sqlcommand);
                Form1.mySqlDataAdapter.Fill(dtdetail);

                lbl_product = new Guna2HtmlLabel[dtdetail.Rows.Count];
                lbl_deadline = new Guna2HtmlLabel[dtdetail.Rows.Count];
                lbl_qty = new Guna2HtmlLabel[dtdetail.Rows.Count];
                lbl_type = new Guna2HtmlLabel[dtdetail.Rows.Count];
                lbl_total = new Guna2HtmlLabel[dtdetail.Rows.Count];
                pb = new Guna2PictureBox[dtdetail.Rows.Count];

                for (int j = 0; j < dtdetail.Rows.Count; j++)
                {
                    lbl_product[j] = new Guna2HtmlLabel();
                    lbl_product[j].Location = new Point(262, y3);
                    lbl_product[j].Size = new Size(497, 33);
                    lbl_product[j].Text = "Product : " + dtdetail.Rows[j][0].ToString();
                    lbl_product[j].Font = new Font("Microsoft Sans Serif", 24);
                    lbl_product[j].ForeColor = Color.Black;
                    y3 += 50;
                    lbl_type[j] = new Guna2HtmlLabel();
                    lbl_qty[j] = new Guna2HtmlLabel();
                    lbl_deadline[j] = new Guna2HtmlLabel();
                    lbl_total[j] = new Guna2HtmlLabel();
                    pb[j] = new Guna2PictureBox();
                    if (string.IsNullOrEmpty(dtdetail.Rows[j][7].ToString()))
                    {
                        pb[j].Location = new Point(61, y2);
                        pb[j].Size = new Size(203, 192);
                        pb[j].SizeMode = PictureBoxSizeMode.Zoom;
                        y2 += 50;
                    }
                    else
                    {
                        Form1.full_url = Form1.projectDirectory + dtdetail.Rows[j][7].ToString();
                        pb[j].Location = new Point(61, y2);
                        pb[j].Size = new Size(203, 192);
                        pb[j].ImageLocation = Form1.full_url;
                        pb[j].SizeMode = PictureBoxSizeMode.Zoom;
                        y2 += 50;

                    }
                    order[i].Controls.Add(lbl_product[j]);
                    order[i].Controls.Add(pb[j]);
                }
            }
            


        }

        private void pict_minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pict_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            btn_shipping.FillColor = Color.White;
            btn_todo.FillColor = Color.Gold;
            btn_done.FillColor = Color.White;
            btn_canceled.FillColor = Color.White;
            btn_addorder.Show();
            plus1.Show();
            plus2.Show();
            guna2Panel2.Visible = true;
            guna2Panel1.Location = new Point(193, 376);
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            btn_shipping.FillColor = Color.White;
            btn_todo.FillColor = Color.White;
            btn_done.FillColor = Color.Gold;
            btn_canceled.FillColor = Color.White;
            btn_addorder.Hide();
            plus1.Hide();
            plus2.Hide();
            guna2Panel2.Visible = false;
            guna2Panel1.Location = new Point(193, 306);
        }

        private void btn_current_Click(object sender, EventArgs e)
        {

        }

        private void pict_accounticon_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form_Profile form_Profile = new Form_Profile();
            form_Profile.ShowDialog();
        }

        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_addorder_Click(object sender, EventArgs e)
        {
            Add_Order add_Order = new Add_Order();
            add_Order.Show();
            this.Close();
        }

        private void btn_shipping_Click(object sender, EventArgs e)
        {
            btn_shipping.FillColor = Color.Gold;
            btn_todo.FillColor = Color.White;
            btn_done.FillColor = Color.White;
            btn_canceled.FillColor = Color.White;
            btn_addorder.Hide();
            plus1.Hide();
            plus2.Hide();
            guna2Panel2.Visible = false;
            guna2Panel1.Location = new Point(193, 306);
        }

        private void btn_need_Click(object sender, EventArgs e)
        {
            btn_allorder.FillColor = Color.White;
            btn_inprocess.FillColor = Color.White;
            btn_need.FillColor = Color.Gold;
        }

        private void btn_inprocess_Click(object sender, EventArgs e)
        {
            btn_allorder.FillColor = Color.White;
            btn_inprocess.FillColor = Color.Gold;
            btn_need.FillColor = Color.White;
        }

        private void lbl_orders_Click(object sender, EventArgs e)
        {

        }

        private void btn_canceled_Click(object sender, EventArgs e)
        {
            btn_shipping.FillColor = Color.White;
            btn_todo.FillColor = Color.White;
            btn_done.FillColor = Color.White;
            btn_canceled.FillColor = Color.Gold;
            btn_addorder.Hide();
            plus1.Hide();
            plus2.Hide();
            guna2Panel2.Visible = false;
            guna2Panel1.Location = new Point(193, 306);
        }

        private void btn_allorder_Click(object sender, EventArgs e)
        {
            btn_allorder.FillColor = Color.Gold;
            btn_inprocess.FillColor = Color.White;
            btn_need.FillColor = Color.White;
            
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            panel2.BackColor = Color.Gold;
        }


    }
}
